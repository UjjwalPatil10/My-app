const User = [
  {
    id: 1,
    name: "whitw bulb",

    image: "images/bulb-off.png",
    model: "syska",
    // price: "12Rs",
    // description: "lorem",
  },
  {
    id: 2,
    name: "yellow bulb",

    image: "images/bulb-on.png",
    model: "Havells",
    // price: "12Rs",
    // description: "lorem",
  },

  {
    id: 3,
    name: "Bulb",

    image: "images/bulb-on.png",
    model: "breakfast",
    // price: "12Rs",
    // description: "lorem",
  },

  {
    id: 3,
    name: "Bulb",

    image: "images/bulb-on.png",
    model: "breakfast",
    // price: "12Rs",
    // description: "lorem",
  },

  {
    id: 3,
    name: "Bulb",

    image: "images/bulb-on.png",
    model: "breakfast",
    // price: "12Rs",
    // description: "lorem",
  },
];
export default User;
