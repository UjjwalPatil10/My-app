import React from "react";
import OlxClassChild from "./OlxClassChild";
export default class OlxClassParent extends React.Component {
  //Parent Class component
  render() {
    return (
      <section>
        <h3>Olx Component</h3>

        <div
          className="container"
          style={{
            width: "100%",
            // height: "100vh",
            display: "flex",
            flexWrap: "Wrap",
            columnGap: 8,
            rowGap: 13,
          }}
        >
          {/* <OlxClassChild/> */}
          <OlxClassChild name="Olx" price="₹50,000" />
          <OlxClassChild name="Olx" price="₹40,000" />
          <OlxClassChild name="Olx" price="₹30,000" />
          <OlxClassChild name="Olx" price="₹20,000" />
          <OlxClassChild name="Olx" price="₹20,000" />
          <OlxClassChild name="Olx" price="₹80,000" />
        </div>
      </section>
      // <h2>Hello Ram</h2>
    );
  }
}
